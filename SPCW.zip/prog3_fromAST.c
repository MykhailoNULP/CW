#include <stdio.h>
#include <stdlib.h>

int main() 
{
   int _AAAAAAA;
   int _DDDDDDD;
   int _BBBBBBB;
   int _XXXXXXX;
   int _CCCCCCC;
   int _YYYYYYY;
   printf("Enter _AAAAAAA:");
   scanf("%d", &_AAAAAAA);
   printf("Enter _BBBBBBB:");
   scanf("%d", &_BBBBBBB);
   for (int _DDDDDDD = _AAAAAAA; _DDDDDDD <= _BBBBBBB; _DDDDDDD++){
   printf("%d\n", (_DDDDDDD * _DDDDDDD));
}
   for (int _DDDDDDD = _BBBBBBB; _DDDDDDD >= _AAAAAAA; _DDDDDDD--){
   printf("%d\n", (_DDDDDDD * _DDDDDDD));
}
   _XXXXXXX = 0;
   _CCCCCCC = 0;
   while (_CCCCCCC < _AAAAAAA)
   {
   _YYYYYYY = 0;
   while (_YYYYYYY < _BBBBBBB)
   {
   _XXXXXXX = (_XXXXXXX + 1);
   _YYYYYYY = (_YYYYYYY + 1);
   }
   _CCCCCCC = (_CCCCCCC + 1);
   }
   printf("%d\n", _XXXXXXX);
   _XXXXXXX = 0;
   _CCCCCCC = 1;
   do{
   
   
   _YYYYYYY = 1;
   do{
   
   _XXXXXXX = (_XXXXXXX + 1);
   _YYYYYYY = (_YYYYYYY + 1);
   } while (!(_YYYYYYY > _BBBBBBB));
   _CCCCCCC = (_CCCCCCC + 1);
   } while (!(_CCCCCCC > _AAAAAAA));
   printf("%d\n", _XXXXXXX);
   system("pause");
    return 0;
}
