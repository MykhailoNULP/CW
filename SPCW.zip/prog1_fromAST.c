#include <stdio.h>
#include <stdlib.h>

int main() 
{
   int _AAAAAAA;
   int _BBBBBBB;
   int _XXXXXXX;
   int _YYYYYYY;
   printf("Enter _AAAAAAA:");
   scanf("%d", &_AAAAAAA);
   printf("Enter _BBBBBBB:");
   scanf("%d", &_BBBBBBB);
   printf("%d\n", (_AAAAAAA + _BBBBBBB));
   printf("%d\n", (_AAAAAAA - _BBBBBBB));
   printf("%d\n", (_AAAAAAA * _BBBBBBB));
   printf("%d\n", (_AAAAAAA / _BBBBBBB));
   printf("%d\n", (_AAAAAAA % _BBBBBBB));
   _XXXXXXX = (((_AAAAAAA - _BBBBBBB) * 10) + ((_AAAAAAA + _BBBBBBB) / 10));
   _YYYYYYY = (_XXXXXXX + (_XXXXXXX % 10));
   printf("%d\n", _XXXXXXX);
   printf("%d\n", _YYYYYYY);
   system("pause");
    return 0;
}
