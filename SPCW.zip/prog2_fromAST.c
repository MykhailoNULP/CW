#include <stdio.h>
#include <stdlib.h>

int main() 
{
   int _AAAAAAA;
   int _BBBBBBB;
   int _CCCCCCC;
   int _TTTTTTT;
   printf("Enter _AAAAAAA:");
   scanf("%d", &_AAAAAAA);
   printf("Enter _BBBBBBB:");
   scanf("%d", &_BBBBBBB);
   printf("Enter _CCCCCCC:");
   scanf("%d", &_CCCCCCC);
   if (_BBBBBBB > _AAAAAAA) 
{ 
   goto Abigger;
} 
   else{
   _TTTTTTT = _AAAAAAA;
} 
Outofib:
   if ((_CCCCCCC > _BBBBBBB && _CCCCCCC > _AAAAAAA)) 
{ 
   goto Outofic;
} 
   else{
   goto Outofif;
} 
Abigger:
   _TTTTTTT = _BBBBBBB;
   goto Outofib;
Outofic:
   _TTTTTTT = _CCCCCCC;
   goto Outofif;
Outofif:
   printf("%d\n", _TTTTTTT);
   if (((_AAAAAAA == _BBBBBBB && _AAAAAAA == _CCCCCCC) && _BBBBBBB == _CCCCCCC)) 
{ 
   printf("%d\n", 1);
} 
   else{
   printf("%d\n", 0);
} 
   if (((_AAAAAAA < 0 || _BBBBBBB < 0) || _CCCCCCC < 0)) 
{ 
   printf("%d\n", (0 - 1));
} 
   else{
   printf("%d\n", 0);
} 
   if (!(_AAAAAAA < (_BBBBBBB + _CCCCCCC))) 
{ 
   printf("%d\n", 10);
} 
   else{
   printf("%d\n", 0);
} 
   system("pause");
    return 0;
}
